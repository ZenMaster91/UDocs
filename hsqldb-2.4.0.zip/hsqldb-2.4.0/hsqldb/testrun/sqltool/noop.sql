/*
 * $Id: noop.sql 610 2008-12-22 15:54:18Z unsaved $
 *
 * Simplest test possible.  Does absolutely nothing.
 */
