/*
 * $Id: tblx.sql 3714 2010-07-22 02:28:38Z unsaved $
 *
 * Test loading other files with @
 */

CREATE TABLE tblx (
    id INTEGER,
    vc VARCHAR(10)
);
